# Zayah Project Status

## Recovery / Stabilization Build — 08 August 2026

This package was reconstructed from the uploaded `Zayah file.zip` backup. The original scattered coding artifacts are preserved under `legacy_source/`.

### Completed in this recovery pass

- Reconstructed a valid Flutter application root.
- Replaced the incorrect Flutter-SDK `_flutter_packages` pubspec with an application pubspec.
- Kept the existing working `lib/`, `web/`, `test/`, docs, and project metadata.
- Removed stray root `main.dart.dart` and `pubspec.yaml.dart` artifacts from the active app root.
- Integrated `go_router` into `MaterialApp.router`.
- Added a centralized `GetIt` dependency bootstrap (`lib/core/di/injection.dart`).
- Preserved all prior scattered source artifacts under `legacy_source/` for recovery and later migration.

### Still blocked on environment/configuration

- Firebase project configuration (`firebase_options.dart`, Android/iOS Firebase files).
- Real Firestore/Auth/Storage/FCM wiring and security rules validation.
- KNET merchant/backend credentials and callback endpoint.
- Google Maps API keys and platform configuration.
- Android and iOS platform folders were not present in the uploaded backup, so release builds cannot be verified from this package alone.

### Next locked sprint

1. Wire the recovered domain/data modules into GetIt.
2. Add Firebase initialization after project configuration is supplied.
3. Complete Firestore/Auth/Storage/FCM integration.
4. Complete Maps integration.
5. Complete KNET backend integration.
6. Run `flutter pub get`, `flutter analyze`, tests, and platform builds in a Flutter-enabled environment.

No new business feature is being started until the production integration sprint is complete.


## Sprint 3 — Firestore Repository Migration
- Completed: customer order Firestore datasource, model mapping, repository, use cases, controller, real-time orders page, DI registration, route, and composite index.
- Next: Firebase Storage use-case integration, FCM, Maps, KNET backend.


## Sprint 4 — Firebase Storage Integration
- Completed: shared media repository and use cases.
- Completed: profile, provider portfolio, service image, and chat attachment paths.
- Completed: Storage security rules aligned to client paths.
- Pending: live Firebase project verification and platform build/test.

## Sprint 5 — Firebase Cloud Messaging
- Added FCM initialization service.
- Added foreground message stream.
- Added notification-token persistence foundation in Firestore.
- Added background-message entry point.
- Added token security baseline.
- Pending: real Firebase project/platform verification and notification UI/display configuration.

## Sprint 6 — Google Maps / Live Tracking Foundation
- Added technician location domain entity.
- Added Firestore live location datasource/repository.
- Added watch/update location use cases.
- Registered maps dependencies in GetIt.
- Added Google Maps package and setup documentation.
- Added Firestore security baseline for technician locations.
- Pending: real device GPS permissions, map UI, API-key configuration, route/ETA verification.

## Sprint 7 started
- KNET Flutter domain/repository/use cases added.
- KNET backend client added.
- Firebase Functions create/status/callback endpoints added.
- Server-side order and payment validation added.
- Firestore payment writes made server-authoritative.
- Official KNET signature verification remains a required external integration step.

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get_it/get_it.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';

import '../../features/auth/data/services/auth_service.dart';
import '../../features/checkout/data/datasources/checkout_firestore_datasource.dart';
import '../../features/checkout/data/repositories/firestore_checkout_repository.dart';
import '../../features/checkout/domain/repositories/checkout_repository.dart';
import '../../features/checkout/domain/services/checkout_service.dart';
import '../../features/checkout/presentation/controllers/checkout_controller.dart';
import '../services/firebase_bootstrap.dart';
import '../services/firebase_storage_service.dart';
import '../services/firestore_service.dart';

final GetIt sl = GetIt.instance;

Future<void> configureDependencies() async {
  final firebaseReady = await FirebaseBootstrap.initialize();
  if (!firebaseReady || Firebase.apps.isEmpty) {
    return;
  }

  if (!sl.isRegistered<FirebaseAuth>()) {
    sl.registerLazySingleton<FirebaseAuth>(FirebaseAuth.instance);
  }

  if (!sl.isRegistered<FirebaseFirestore>()) {
    sl.registerLazySingleton<FirebaseFirestore>(FirebaseFirestore.instance);
  }

  if (!sl.isRegistered<FirebaseStorage>()) {
    sl.registerLazySingleton<FirebaseStorage>(FirebaseStorage.instance);
  }

  if (!sl.isRegistered<FirestoreService>()) {
    sl.registerLazySingleton<FirestoreService>(
      () => FirestoreService(sl<FirebaseFirestore>()),
    );
  }

  if (!sl.isRegistered<FirebaseStorageService>()) {
    sl.registerLazySingleton<FirebaseStorageService>(
      () => FirebaseStorageService(sl<FirebaseStorage>()),
    );
  }

  if (!sl.isRegistered<AuthService>()) {
    sl.registerLazySingleton<AuthService>(() => AuthService(sl<FirebaseAuth>()));
  }

  if (!sl.isRegistered<CheckoutFirestoreDataSource>()) {
    sl.registerLazySingleton<CheckoutFirestoreDataSource>(
      () => CheckoutFirestoreDataSource(sl<FirebaseFirestore>()),
    );
  }

  if (!sl.isRegistered<CheckoutRepository>()) {
    sl.registerLazySingleton<CheckoutRepository>(
      () => FirestoreCheckoutRepository(
        dataSource: sl<CheckoutFirestoreDataSource>(),
        currentUserId: () => sl<AuthService>().currentUser?.uid,
      ),
    );
  }

  if (!sl.isRegistered<CheckoutService>()) {
    sl.registerLazySingleton<CheckoutService>(
      () => CheckoutService(repository: sl<CheckoutRepository>()),
    );
  }
}

CheckoutController createCheckoutController() {
  if (!sl.isRegistered<CheckoutService>()) {
    throw StateError(
      'Firebase is not configured. Configure Firebase before opening checkout.',
    );
  }
  return CheckoutController(service: sl<CheckoutService>());
}

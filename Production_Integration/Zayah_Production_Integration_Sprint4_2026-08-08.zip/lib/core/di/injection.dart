import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get_it/get_it.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';

import '../../features/auth/data/services/auth_service.dart';
import '../../features/checkout/data/datasources/checkout_firestore_datasource.dart';
import '../../features/checkout/data/repositories/firestore_checkout_repository.dart';
import '../../features/checkout/domain/repositories/checkout_repository.dart';
import '../../features/checkout/domain/services/checkout_service.dart';
import '../../features/checkout/presentation/controllers/checkout_controller.dart';
import '../../features/orders/data/datasources/order_firestore_datasource.dart';
import '../../features/orders/data/repositories/firestore_order_repository.dart';
import '../../features/orders/domain/repositories/order_repository.dart';
import '../../features/orders/domain/usecases/get_order_usecase.dart';
import '../../features/orders/domain/usecases/watch_customer_orders_usecase.dart';
import '../../features/orders/presentation/controllers/order_controller.dart';
import '../services/firebase_bootstrap.dart';
import '../services/firebase_storage_service.dart';
import '../services/firestore_service.dart';
import '../storage/storage_path_builder.dart';
import '../../features/media/data/repositories/firebase_media_repository.dart';
import '../../features/media/domain/repositories/media_repository.dart';
import '../../features/media/domain/usecases/upload_media_usecases.dart';

final GetIt sl = GetIt.instance;

Future<void> configureDependencies() async {
  final firebaseReady = await FirebaseBootstrap.initialize();
  if (!firebaseReady || Firebase.apps.isEmpty) {
    return;
  }

  if (!sl.isRegistered<FirebaseAuth>()) {
    sl.registerLazySingleton<FirebaseAuth>(FirebaseAuth.instance);
  }

  if (!sl.isRegistered<FirebaseFirestore>()) {
    sl.registerLazySingleton<FirebaseFirestore>(FirebaseFirestore.instance);
  }

  if (!sl.isRegistered<FirebaseStorage>()) {
    sl.registerLazySingleton<FirebaseStorage>(FirebaseStorage.instance);
  }

  if (!sl.isRegistered<FirestoreService>()) {
    sl.registerLazySingleton<FirestoreService>(
      () => FirestoreService(sl<FirebaseFirestore>()),
    );
  }

  if (!sl.isRegistered<FirebaseStorageService>()) {
    sl.registerLazySingleton<FirebaseStorageService>(
      () => FirebaseStorageService(sl<FirebaseStorage>()),
    );
  }

  if (!sl.isRegistered<StoragePathBuilder>()) {
    sl.registerLazySingleton<StoragePathBuilder>(
      () => StoragePathBuilder(sl<FirebaseAuth>()),
    );
  }

  if (!sl.isRegistered<MediaRepository>()) {
    sl.registerLazySingleton<MediaRepository>(
      () => FirebaseMediaRepository(
        storage: sl<FirebaseStorageService>(),
        paths: sl<StoragePathBuilder>(),
      ),
    );
  }

  if (!sl.isRegistered<UploadProfileImageUseCase>()) {
    sl.registerLazySingleton<UploadProfileImageUseCase>(
      () => UploadProfileImageUseCase(sl<MediaRepository>()),
    );
  }

  if (!sl.isRegistered<UploadProviderPortfolioImageUseCase>()) {
    sl.registerLazySingleton<UploadProviderPortfolioImageUseCase>(
      () => UploadProviderPortfolioImageUseCase(sl<MediaRepository>()),
    );
  }

  if (!sl.isRegistered<UploadServiceImageUseCase>()) {
    sl.registerLazySingleton<UploadServiceImageUseCase>(
      () => UploadServiceImageUseCase(sl<MediaRepository>()),
    );
  }

  if (!sl.isRegistered<UploadChatAttachmentUseCase>()) {
    sl.registerLazySingleton<UploadChatAttachmentUseCase>(
      () => UploadChatAttachmentUseCase(sl<MediaRepository>()),
    );
  }

  if (!sl.isRegistered<AuthService>()) {
    sl.registerLazySingleton<AuthService>(() => AuthService(sl<FirebaseAuth>()));
  }

  if (!sl.isRegistered<CheckoutFirestoreDataSource>()) {
    sl.registerLazySingleton<CheckoutFirestoreDataSource>(
      () => CheckoutFirestoreDataSource(sl<FirebaseFirestore>()),
    );
  }

  if (!sl.isRegistered<CheckoutRepository>()) {
    sl.registerLazySingleton<CheckoutRepository>(
      () => FirestoreCheckoutRepository(
        dataSource: sl<CheckoutFirestoreDataSource>(),
        currentUserId: () => sl<AuthService>().currentUser?.uid,
      ),
    );
  }

  if (!sl.isRegistered<OrderFirestoreDataSource>()) {
    sl.registerLazySingleton<OrderFirestoreDataSource>(
      () => OrderFirestoreDataSource(sl<FirebaseFirestore>()),
    );
  }

  if (!sl.isRegistered<OrderRepository>()) {
    sl.registerLazySingleton<OrderRepository>(
      () => FirestoreOrderRepository(sl<OrderFirestoreDataSource>()),
    );
  }

  if (!sl.isRegistered<WatchCustomerOrdersUseCase>()) {
    sl.registerLazySingleton<WatchCustomerOrdersUseCase>(
      () => WatchCustomerOrdersUseCase(sl<OrderRepository>()),
    );
  }

  if (!sl.isRegistered<GetOrderUseCase>()) {
    sl.registerLazySingleton<GetOrderUseCase>(
      () => GetOrderUseCase(sl<OrderRepository>()),
    );
  }

  if (!sl.isRegistered<CheckoutService>()) {
    sl.registerLazySingleton<CheckoutService>(
      () => CheckoutService(repository: sl<CheckoutRepository>()),
    );
  }
}

CheckoutController createCheckoutController() {
  if (!sl.isRegistered<CheckoutService>()) {
    throw StateError(
      'Firebase is not configured. Configure Firebase before opening checkout.',
    );
  }
  return CheckoutController(service: sl<CheckoutService>());
}

OrderController createOrderController() {
  if (!sl.isRegistered<OrderRepository>()) {
    throw StateError(
      'Firebase is not configured. Configure Firebase before opening orders.',
    );
  }
  return OrderController(
    watchOrders: sl<WatchCustomerOrdersUseCase>(),
    getOrder: sl<GetOrderUseCase>(),
    currentUserId: () => sl<AuthService>().currentUser?.uid,
  );
}

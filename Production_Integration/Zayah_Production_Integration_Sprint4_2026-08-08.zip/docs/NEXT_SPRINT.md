# Zayah — Next Sprint

## Completed
- Sprint 1: DI + Firebase bootstrap + Firestore checkout foundation
- Sprint 2: Shared Firestore/Storage services
- Sprint 3: Firestore customer order repository and real-time order stream
- Sprint 4: Storage media repository and production upload paths

## Next
1. Firebase Cloud Messaging
2. Notification token persistence
3. Foreground/background notification handling
4. Google Maps + technician live tracking
5. Real KNET backend/callback
6. End-to-end build/test verification

No unrelated feature work should start before the locked production integration queue is complete.

# Zayah Production Integration Queue

## Completed in this recovery pass
- Corrected the application `pubspec.yaml`.
- Added guarded Firebase bootstrap.
- Added GetIt registrations for Firebase Auth, Firestore, checkout datasource, repository and service.
- Replaced the checkout route's in-memory repository with the Firestore repository.
- Added initial Firestore and Storage security rules.
- Kept legacy recovered source under `legacy_source/` for audit/recovery.

## Next locked work
1. Firebase project configuration (`firebase_options.dart` or production dart-defines + native config).
2. Authentication UI binding to `AuthService` and route/session guard.
3. Firestore repositories for marketplace, orders, notifications and chat.
4. Firebase Storage upload service.
5. FCM token registration and foreground/background handling.
6. Google Maps configuration and technician location stream.
7. KNET backend contract + secure callback verification (server-side only).
8. Automated tests and platform builds.

No new major business feature should start before this integration queue is complete.

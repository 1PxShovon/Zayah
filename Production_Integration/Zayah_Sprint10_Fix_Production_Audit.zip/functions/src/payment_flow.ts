import * as admin from "firebase-admin";

export async function applyVerifiedPaymentToOrder(
  transactionId: string,
  verifiedStatus: "paid" | "failed" | "cancelled" | "refunded",
): Promise<void> {
  const db = admin.firestore();
  const transactionRef = db.collection("payment_transactions").doc(transactionId);
  const transaction = await transactionRef.get();

  if (!transaction.exists) {
    throw new Error("TRANSACTION_NOT_FOUND");
  }

  const payment = transaction.data()!;
  const orderId = String(payment.orderId ?? "");
  const userId = String(payment.userId ?? "");

  if (!orderId || !userId) {
    throw new Error("INVALID_PAYMENT_RECORD");
  }

  const orderRef = db.collection("orders").doc(orderId);

  await db.runTransaction(async (tx) => {
    const order = await tx.get(orderRef);

    if (!order.exists) {
      throw new Error("ORDER_NOT_FOUND");
    }

    const orderData = order.data()!;

    if (orderData.customerId !== userId) {
      throw new Error("ORDER_OWNER_MISMATCH");
    }

    if (Number(orderData.total) !== Number(payment.amount)) {
      throw new Error("AMOUNT_MISMATCH");
    }

    if (orderData.currency !== payment.currency) {
      throw new Error("CURRENCY_MISMATCH");
    }

    const orderStatus =
      verifiedStatus === "paid" ? "confirmed" : "payment_failed";

    tx.set(
      transactionRef,
      {
        status: verifiedStatus,
        verifiedAt: admin.firestore.FieldValue.serverTimestamp(),
      },
      {merge: true},
    );

    tx.set(
      orderRef,
      {
        paymentStatus: verifiedStatus,
        status: orderStatus,
        paymentTransactionId: transactionId,
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      },
      {merge: true},
    );

    const notificationRef = db.collection("notifications").doc();
    tx.create(notificationRef, {
      userId,
      orderId,
      type: "payment_status",
      status: verifiedStatus,
      read: false,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  });
}

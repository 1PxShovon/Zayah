import {onRequest} from "firebase-functions/v2/https";
import {defineSecret} from "firebase-functions/params";
import * as admin from "firebase-admin";
admin.initializeApp();
const db=admin.firestore();

const KNET_CREATE_URL=defineSecret("KNET_CREATE_URL");
const KNET_STATUS_URL=defineSecret("KNET_STATUS_URL");
const KNET_API_KEY=defineSecret("KNET_API_KEY");
const KNET_MERCHANT_ID=defineSecret("KNET_MERCHANT_ID");

async function user(req:any) {
  const h=req.headers.authorization||"";
  if(!h.startsWith("Bearer ")) throw new Error("UNAUTHENTICATED");
  return admin.auth().verifyIdToken(h.substring(7));
}
function status(v:any):string {
  const s=String(v??"").toLowerCase();
  if(["paid","success","successful"].includes(s)) return "paid";
  if(s==="failed") return "failed";
  if(["cancelled","canceled"].includes(s)) return "cancelled";
  if(s==="refunded") return "refunded";
  return "pending";
}
async function gateway(url:string, body:any) {
  const r=await fetch(url,{method:"POST",headers:{
    "content-type":"application/json",
    "authorization":`Bearer ${KNET_API_KEY.value()}`,
    "x-merchant-id":KNET_MERCHANT_ID.value()
  },body:JSON.stringify(body)});
  const text=await r.text();
  if(!r.ok) throw new Error(`Gateway ${r.status}: ${text}`);
  return JSON.parse(text);
}
function err(res:any,n:number,m:string){return res.status(n).json({error:m});}

export const createKnetPayment=onRequest({
  region:"me-central2",
  secrets:[KNET_CREATE_URL,KNET_STATUS_URL,KNET_API_KEY,KNET_MERCHANT_ID]
},async(req,res)=>{
  try {
    if(req.method!=="POST") return err(res,405,"Method not allowed");
    const u=await user(req);
    const {orderId,amount,currency}=req.body??{};
    if(typeof orderId!=="string"||!Number.isFinite(Number(amount))||typeof currency!=="string")
      return err(res,400,"Invalid payment request");

    const order=await db.collection("orders").doc(orderId).get();
    if(!order.exists) return err(res,404,"Order not found");
    const o=order.data()!;
    if(o.customerId!==u.uid) return err(res,403,"Forbidden");
    if(Math.abs(Number(o.total)-Number(amount))>.001||o.currency!==currency)
      return err(res,409,"Amount/currency mismatch");
    if(o.status!=="pending_payment") return err(res,409,"Order is not awaiting payment");

    const ref=db.collection("payment_transactions").doc();
    const gatewayResult=await gateway(KNET_CREATE_URL.value(),{
      transactionId:ref.id,orderId,amount:Number(amount),currency,customerId:u.uid
    });

    await ref.set({
      transactionId:ref.id,orderId,userId:u.uid,amount:Number(amount),currency,
      status:"pending",
      gatewayReference:gatewayResult.gatewayReference??null,
      paymentUrl:gatewayResult.paymentUrl??null,
      createdAt:admin.firestore.FieldValue.serverTimestamp()
    });

    return res.status(201).json({
      transactionId:ref.id,status:"pending",
      gatewayReference:gatewayResult.gatewayReference??null,
      paymentUrl:gatewayResult.paymentUrl??null
    });
  } catch(e) {
    if(String(e).includes("UNAUTHENTICATED")) return err(res,401,"Authentication required");
    console.error(e); return err(res,500,"Payment initialization failed");
  }
});

export const getKnetPaymentStatus=onRequest({
  region:"me-central2",
  secrets:[KNET_CREATE_URL,KNET_STATUS_URL,KNET_API_KEY,KNET_MERCHANT_ID]
},async(req,res)=>{
  try {
    if(req.method!=="GET") return err(res,405,"Method not allowed");
    const u=await user(req);
    const id=String(req.path).split("/").filter(Boolean).pop()||"";
    const ref=db.collection("payment_transactions").doc(id);
    const snap=await ref.get();
    if(!snap.exists) return err(res,404,"Transaction not found");
    const t=snap.data()!;
    if(t.userId!==u.uid) return err(res,403,"Forbidden");

    const r=await fetch(`${KNET_STATUS_URL.value()}/${encodeURIComponent(id)}`,{
      headers:{"authorization":`Bearer ${KNET_API_KEY.value()}`,"x-merchant-id":KNET_MERCHANT_ID.value()}
    });
    if(!r.ok) return err(res,502,"Gateway status verification failed");
    const g=await r.json() as any;
    return res.json({transactionId:id,status:status(g.status),
      gatewayReference:g.gatewayReference??t.gatewayReference,paymentUrl:t.paymentUrl??null});
  } catch(e) {
    if(String(e).includes("UNAUTHENTICATED")) return err(res,401,"Authentication required");
    console.error(e); return err(res,500,"Payment verification failed");
  }
});

export const knetCallback=onRequest({
  region:"me-central2",
  secrets:[KNET_API_KEY,KNET_MERCHANT_ID]
},async(req,res)=>{
  try {
    if(req.method!=="POST") return err(res,405,"Method not allowed");
    const body=req.body??{};
    const id=String(body.transactionId??"");
    if(!id) return err(res,400,"Missing transactionId");
    const ref=db.collection("payment_transactions").doc(id);
    const snap=await ref.get();
    if(!snap.exists) return err(res,404,"Transaction not found");

    // SECURITY GATE:
    // Exact signature validation MUST be implemented from the official KNET
    // merchant/acquirer specification before accepting a paid callback.
    if(status(body.status)==="paid")
      return err(res,501,"Official KNET callback signature verification required");

    await ref.set({
      callbackStatus:status(body.status),
      callbackReceivedAt:admin.firestore.FieldValue.serverTimestamp()
    },{merge:true});
    return res.status(202).json({accepted:true});
  } catch(e) {
    console.error(e); return err(res,500,"Callback processing failed");
  }
});


export const verifyKnetAndConfirmOrder = onRequest(
  {
    region: "me-central2",
    secrets: [
      KNET_STATUS_URL,
      KNET_API_KEY,
      KNET_MERCHANT_ID,
    ],
  },
  async (req, res) => {
    try {
      if (req.method !== "POST") {
        return jsonError(res, 405, "Method not allowed");
      }

      const user = await requireUser(req);
      const { transactionId } = req.body ?? {};

      if (typeof transactionId !== "string" || !transactionId) {
        return jsonError(res, 400, "transactionId is required");
      }

      const transactionRef =
        db.collection("payment_transactions").doc(transactionId);
      const snapshot = await transactionRef.get();

      if (!snapshot.exists) {
        return jsonError(res, 404, "Transaction not found");
      }

      const payment = snapshot.data()!;
      if (payment.userId !== user.uid) {
        return jsonError(res, 403, "Transaction does not belong to user");
      }

      // Real gateway verification occurs server-to-server.
      const gatewayResponse = await fetch(
        `${KNET_STATUS_URL.value()}/${encodeURIComponent(transactionId)}`,
        {
          headers: {
            authorization: `Bearer ${KNET_API_KEY.value()}`,
            "x-merchant-id": KNET_MERCHANT_ID.value(),
          },
        },
      );

      const body = await gatewayResponse.text();
      if (!gatewayResponse.ok) {
        return jsonError(res, 502, "KNET verification failed");
      }

      const gateway = JSON.parse(body) as Record<string, unknown>;
      const status = normalizeStatus(gateway.status);

      if (status === "paid") {
        await applyVerifiedPaymentToOrder(transactionId, "paid");
      } else if (status === "failed") {
        await applyVerifiedPaymentToOrder(transactionId, "failed");
      } else if (status === "cancelled") {
        await applyVerifiedPaymentToOrder(transactionId, "cancelled");
      }

      return res.json({
        transactionId,
        status,
        orderConfirmed: status === "paid",
      });
    } catch (error) {
      if (String(error).includes("UNAUTHENTICATED")) {
        return jsonError(res, 401, "Authentication required");
      }
      console.error(error);
      return jsonError(res, 500, "Payment/order verification failed");
    }
  },
);

# Sprint 8 — Booking → KNET → Verification → Order → Notification

## Implemented
- Server-authoritative payment-to-order transition.
- Verified paid payment changes the order to `confirmed`.
- Failed/cancelled payment changes the order to `payment_failed`.
- Payment transaction and order are updated atomically.
- A notification record is created in the same Firestore transaction.
- Authenticated verification endpoint added.

## Required for real production verification
The KNET merchant/acquirer specification and credentials must be configured.
The exact gateway response and callback signature must be validated before
treating any external callback as trusted.

## State machine

`pending_payment`
→ `payment pending`
→ `paid`
→ `confirmed`
→ notification

or

`pending_payment`
→ `payment pending`
→ `failed/cancelled`
→ `payment_failed`

No client-side code can directly mark an order as paid/confirmed.

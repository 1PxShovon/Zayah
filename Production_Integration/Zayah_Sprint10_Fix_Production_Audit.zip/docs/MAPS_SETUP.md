# Zayah Google Maps / Live Tracking

## Architecture
- `TechnicianLocationFirestoreDataSource` stores the technician's last known coordinates.
- `TechnicianLocationRepository` converts Firestore data into domain entities.
- `WatchTechnicianLocation` exposes a real-time stream to tracking UI.
- `UpdateTechnicianLocation` is the write boundary for technician location updates.

## Firestore
Collection:
`technician_locations/{technicianId}`

Fields:
- `technicianId`
- `latitude`
- `longitude`
- `updatedAt`

## Platform configuration
Before release, configure a restricted Google Maps API key for:
- Android Maps SDK
- iOS Maps SDK
- Web Maps/Maps JavaScript API as required by the chosen web implementation

Do not commit unrestricted API keys. Use platform secrets / CI environment variables.

## Important
This sprint provides the production data/integration boundary. Device GPS permission,
background location tracking, map rendering, route polylines and ETA require platform
configuration and should be verified on real Android/iOS devices before release.

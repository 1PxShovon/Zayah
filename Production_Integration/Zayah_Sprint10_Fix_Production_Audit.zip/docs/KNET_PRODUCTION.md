# Zayah Sprint 7 — KNET

Implemented:
- Authenticated Flutter payment client.
- KNET repository and use cases.
- Server-side order ownership validation.
- Server-side amount/currency validation.
- Server-generated transaction ID.
- Firestore payment transaction persistence.
- Server-side gateway status verification endpoint.
- Callback endpoint with a deliberate security gate.

Required before live payment:
- Official KNET/acquirer API specification.
- Merchant credentials.
- Exact callback signature/encryption validation.
- Production callback URL.
- Gateway create/status endpoint values.

Secrets must stay in Firebase Functions secrets, never in Flutter/Git.

Set Flutter backend URL:
`--dart-define=KNET_BACKEND_URL=https://<production-backend>`

The callback intentionally refuses to confirm `paid` until official signature
verification is configured.

# Zayah Recovery Manifest

## Source
Recovered from the uploaded `Zayah file.zip` on 08 August 2026.

## Active application source
The active buildable application is the root-level `lib/` + `web/` + `test/` set.

## Preserved legacy source
All previously generated/scattered Zayah coding artifacts are preserved in `legacy_source/`. Nothing from that source was intentionally deleted.

## Completed in this recovery build
- Correct Flutter app package name and pubspec structure.
- GoRouter integrated through `MaterialApp.router`.
- Central GetIt bootstrap added.
- Existing home/sign-in/checkout flow preserved.
- Home navigation converted from named Navigator routes to GoRouter navigation.
- Legacy artifacts retained for subsequent domain migration.

## Not falsely marked complete
Real Firebase, FCM, Google Maps, and KNET production integrations require project configuration, credentials, backend endpoints, and platform configuration that were not present in the uploaded archive. Those remain explicit integration tasks rather than fake/demo implementations.

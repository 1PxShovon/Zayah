abstract final class AppRoutes {
  static const String home = '/';
  static const String signIn = '/sign-in';
  static const String checkout = '/checkout';
  static const String orders = '/orders';
}

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/presentation/pages/sign_in_page.dart';
import '../../features/checkout/presentation/pages/checkout_page.dart';
import '../../core/di/injection.dart';
import '../../features/home/presentation/pages/home_page.dart';
import '../../features/orders/presentation/pages/orders_page.dart';
import 'app_routes.dart';

final GlobalKey<NavigatorState> rootNavigatorKey = GlobalKey<NavigatorState>();

final GoRouter appRouter = GoRouter(
  navigatorKey: rootNavigatorKey,
  initialLocation: AppRoutes.home,
  routes: <RouteBase>[
    GoRoute(
      path: AppRoutes.home,
      builder: (context, state) => const HomePage(),
    ),
    GoRoute(
      path: AppRoutes.signIn,
      builder: (context, state) => const SignInPage(),
    ),
    GoRoute(
      path: AppRoutes.orders,
      builder: (context, state) => OrdersPage(
        controller: createOrderController(),
      ),
    ),
    GoRoute(
      path: AppRoutes.checkout,
      builder: (context, state) {
        return CheckoutPage(controller: createCheckoutController());
      },
    ),
  ],
  errorBuilder: (context, state) => Scaffold(
    appBar: AppBar(title: const Text('Zayah')),
    body: Center(
      child: Text('Page not found: ${state.uri.path}'),
    ),
  ),
);

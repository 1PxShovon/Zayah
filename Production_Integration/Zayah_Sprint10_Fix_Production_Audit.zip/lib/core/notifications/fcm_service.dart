import 'dart:async';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';

class FcmService {
  FcmService(this._messaging);

  final FirebaseMessaging _messaging;

  final StreamController<RemoteMessage> _messages =
      StreamController<RemoteMessage>.broadcast();

  StreamSubscription<RemoteMessage>? _foregroundSubscription;

  Stream<RemoteMessage> get foregroundMessages => _messages.stream;

  Future<void> initialize() async {
    final settings = await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      provisional: false,
    );

    if (settings.authorizationStatus == AuthorizationStatus.denied) {
      return;
    }

    await _messaging.setAutoInitEnabled(true);

    final token = await _messaging.getToken();
    if (kDebugMode && token != null) {
      debugPrint('FCM token: $token');
    }

    _foregroundSubscription ??=
        FirebaseMessaging.onMessage.listen(_messages.add);
  }

  Future<String?> getToken() => _messaging.getToken();

  Future<void> subscribeToTopic(String topic) =>
      _messaging.subscribeToTopic(topic);

  Future<void> unsubscribeFromTopic(String topic) =>
      _messaging.unsubscribeFromTopic(topic);

  Future<void> dispose() async {
    await _foregroundSubscription?.cancel();
    await _messages.close();
  }
}

@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Firebase initialization is intentionally handled by the application
  // bootstrap. Keep this handler side-effect free; platform-specific
  // notification display can be added after Firebase project verification.
}

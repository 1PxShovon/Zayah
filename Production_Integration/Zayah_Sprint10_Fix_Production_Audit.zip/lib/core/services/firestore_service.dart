import 'package:cloud_firestore/cloud_firestore.dart';

/// Small Firestore facade shared by feature repositories.
///
/// Feature-specific repositories should remain responsible for mapping
/// documents to domain models. This class only owns Firestore mechanics.
class FirestoreService {
  FirestoreService(this._firestore);

  final FirebaseFirestore _firestore;

  CollectionReference<Map<String, dynamic>> collection(String path) {
    return _firestore.collection(path);
  }

  DocumentReference<Map<String, dynamic>> document(String path) {
    return _firestore.doc(path);
  }

  Future<DocumentSnapshot<Map<String, dynamic>>> getDocument(
    String path,
  ) {
    return document(path).get();
  }

  Stream<DocumentSnapshot<Map<String, dynamic>>> watchDocument(
    String path,
  ) {
    return document(path).snapshots();
  }

  Future<void> setDocument(
    String path,
    Map<String, dynamic> data, {
    bool merge = false,
  }) {
    return document(path).set(data, SetOptions(merge: merge));
  }

  Future<void> updateDocument(
    String path,
    Map<String, dynamic> data,
  ) {
    return document(path).update(data);
  }

  Future<void> deleteDocument(String path) {
    return document(path).delete();
  }

  Future<QuerySnapshot<Map<String, dynamic>>> queryCollection(
    String path, {
    String? whereField,
    Object? isEqualTo,
    int? limit,
  }) {
    Query<Map<String, dynamic>> query = collection(path);

    if (whereField != null) {
      query = query.where(whereField, isEqualTo: isEqualTo);
    }

    if (limit != null) {
      query = query.limit(limit);
    }

    return query.get();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> watchCollection(
    String path, {
    String? whereField,
    Object? isEqualTo,
    int? limit,
  }) {
    Query<Map<String, dynamic>> query = collection(path);

    if (whereField != null) {
      query = query.where(whereField, isEqualTo: isEqualTo);
    }

    if (limit != null) {
      query = query.limit(limit);
    }

    return query.snapshots();
  }
}

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

/// Initializes Firebase when the platform has native configuration or when
/// web configuration is supplied through dart-define values.
///
/// Required web defines for production:
/// FIREBASE_API_KEY, FIREBASE_APP_ID, FIREBASE_MESSAGING_SENDER_ID,
/// FIREBASE_PROJECT_ID, FIREBASE_AUTH_DOMAIN, FIREBASE_STORAGE_BUCKET.
abstract final class FirebaseBootstrap {
  static Future<bool> initialize() async {
    if (Firebase.apps.isNotEmpty) {
      return true;
    }

    try {
      if (!kIsWeb) {
        await Firebase.initializeApp();
        return true;
      }

      final apiKey = const String.fromEnvironment('FIREBASE_API_KEY');
      final appId = const String.fromEnvironment('FIREBASE_APP_ID');
      final senderId = const String.fromEnvironment(
        'FIREBASE_MESSAGING_SENDER_ID',
      );
      final projectId = const String.fromEnvironment('FIREBASE_PROJECT_ID');
      final authDomain = const String.fromEnvironment('FIREBASE_AUTH_DOMAIN');
      final storageBucket = const String.fromEnvironment(
        'FIREBASE_STORAGE_BUCKET',
      );

      if ([apiKey, appId, senderId, projectId].any((value) => value.isEmpty)) {
        return false;
      }

      await Firebase.initializeApp(
        options: FirebaseOptions(
          apiKey: apiKey,
          appId: appId,
          messagingSenderId: senderId,
          projectId: projectId,
          authDomain: authDomain.isEmpty ? null : authDomain,
          storageBucket: storageBucket.isEmpty ? null : storageBucket,
        ),
      );
      return true;
    } on FirebaseException catch (error) {
      debugPrint('Firebase initialization failed: ${error.code} ${error.message}');
      return false;
    }
  }
}

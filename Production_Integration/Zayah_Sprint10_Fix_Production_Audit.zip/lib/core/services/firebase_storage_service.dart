import 'dart:typed_data';

import 'package:firebase_storage/firebase_storage.dart';

/// Production-safe Firebase Storage facade.
///
/// Callers must pass a path that is authorized by storage.rules.
/// File size and content type are checked before upload to avoid accidental
/// oversized/unexpected uploads from the client.
class FirebaseStorageService {
  FirebaseStorageService(this._storage);

  final FirebaseStorage _storage;

  static const int maxImageBytes = 10 * 1024 * 1024;
  static const int maxDocumentBytes = 20 * 1024 * 1024;

  Future<String> uploadBytes({
    required String path,
    required Uint8List bytes,
    required String contentType,
    int maxBytes = maxImageBytes,
    Map<String, String>? metadata,
  }) async {
    if (bytes.isEmpty) {
      throw ArgumentError('Cannot upload an empty file.');
    }

    if (bytes.length > maxBytes) {
      throw StateError(
        'File is too large. Maximum allowed size is '
        '${(maxBytes / (1024 * 1024)).ceil()} MB.',
      );
    }

    final ref = _storage.ref(path);
    final snapshot = await ref.putData(
      bytes,
      SettableMetadata(
        contentType: contentType,
        customMetadata: metadata,
      ),
    );

    return snapshot.ref.getDownloadURL();
  }

  Future<String> uploadImage({
    required String path,
    required Uint8List bytes,
    required String contentType,
  }) {
    const allowed = <String>{
      'image/jpeg',
      'image/png',
      'image/webp',
    };

    if (!allowed.contains(contentType)) {
      throw ArgumentError('Unsupported image type: $contentType');
    }

    return uploadBytes(
      path: path,
      bytes: bytes,
      contentType: contentType,
    );
  }

  Future<String> uploadDocument({
    required String path,
    required Uint8List bytes,
    required String contentType,
  }) {
    const allowed = <String>{
      'application/pdf',
      'image/jpeg',
      'image/png',
    };

    if (!allowed.contains(contentType)) {
      throw ArgumentError('Unsupported document type: $contentType');
    }

    return uploadBytes(
      path: path,
      bytes: bytes,
      contentType: contentType,
      maxBytes: maxDocumentBytes,
    );
  }

  Future<void> delete(String path) {
    return _storage.ref(path).delete();
  }

  Future<String> downloadUrl(String path) {
    return _storage.ref(path).getDownloadURL();
  }
}

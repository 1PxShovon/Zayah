import 'package:firebase_auth/firebase_auth.dart';

/// Centralizes Storage paths so clients cannot accidentally create
/// inconsistent locations across profile, provider, service, and chat media.
class StoragePathBuilder {
  const StoragePathBuilder(this._auth);

  final FirebaseAuth _auth;

  String get currentUserId {
    final uid = _auth.currentUser?.uid;
    if (uid == null || uid.isEmpty) {
      throw StateError('A signed-in user is required for this upload.');
    }
    return uid;
  }

  String profileImage() => 'users/$currentUserId/profile/avatar';

  String providerPortfolioImage(String providerId, String assetId) =>
      'providers/$providerId/portfolio/$assetId';

  String serviceImage(String providerId, String serviceId, String assetId) =>
      'providers/$providerId/services/$serviceId/$assetId';

  String chatAttachment(String conversationId, String attachmentId) =>
      'chat/$conversationId/attachments/$attachmentId';
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class NotificationTokenRepository {
  NotificationTokenRepository({
    required FirebaseFirestore firestore,
    required FirebaseAuth auth,
  })  : _firestore = firestore,
        _auth = auth;

  final FirebaseFirestore _firestore;
  final FirebaseAuth _auth;

  Future<void> saveCurrentToken(String token) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null || uid.isEmpty || token.isEmpty) return;

    await _firestore
        .collection('users')
        .doc(uid)
        .collection('notification_tokens')
        .doc(token)
        .set({
      'token': token,
      'platform': _platformName,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<void> removeCurrentToken(String token) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null || uid.isEmpty || token.isEmpty) return;

    await _firestore
        .collection('users')
        .doc(uid)
        .collection('notification_tokens')
        .doc(token)
        .delete();
  }

  String get _platformName {
    // Keep this dependency-free so the repository remains testable.
    return 'unknown';
  }
}

abstract class NotificationRepository {
  Future<void> sendPaymentStatusNotification({
    required String userId,
    required String orderId,
    required String status,
  });
}

import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../domain/entities/order.dart';
import '../../domain/usecases/get_order_usecase.dart';
import '../../domain/usecases/watch_customer_orders_usecase.dart';

class OrderController extends ChangeNotifier {
  OrderController({
    required WatchCustomerOrdersUseCase watchOrders,
    required GetOrderUseCase getOrder,
    required String? Function() currentUserId,
  })  : _watchOrders = watchOrders,
        _getOrder = getOrder,
        _currentUserId = currentUserId;

  final WatchCustomerOrdersUseCase _watchOrders;
  final GetOrderUseCase _getOrder;
  final String? Function() _currentUserId;

  StreamSubscription<List<ZayahOrder>>? _subscription;

  List<ZayahOrder> orders = const [];
  ZayahOrder? selectedOrder;
  String? errorMessage;
  bool isLoading = false;

  void startWatching() {
    final userId = _currentUserId();
    if (userId == null || userId.isEmpty) {
      errorMessage = 'Sign in to view your orders.';
      notifyListeners();
      return;
    }

    isLoading = true;
    errorMessage = null;
    notifyListeners();

    _subscription?.cancel();
    _subscription = _watchOrders(userId).listen(
      (value) {
        orders = value;
        isLoading = false;
        notifyListeners();
      },
      onError: (Object error) {
        isLoading = false;
        errorMessage = 'Unable to load orders.';
        notifyListeners();
      },
    );
  }

  Future<void> loadOrder(String orderId) async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();

    try {
      selectedOrder = await _getOrder(orderId);
    } catch (_) {
      errorMessage = 'Unable to load this order.';
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }
}

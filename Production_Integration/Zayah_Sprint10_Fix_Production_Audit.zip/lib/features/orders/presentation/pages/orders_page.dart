import 'package:flutter/material.dart';

import '../controllers/order_controller.dart';

class OrdersPage extends StatefulWidget {
  const OrdersPage({required this.controller, super.key});

  final OrderController controller;

  @override
  State<OrdersPage> createState() => _OrdersPageState();
}

class _OrdersPageState extends State<OrdersPage> {
  @override
  void initState() {
    super.initState();
    widget.controller.startWatching();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.controller,
      builder: (context, _) {
        if (widget.controller.isLoading &&
            widget.controller.orders.isEmpty) {
          return const Center(child: CircularProgressIndicator());
        }

        if (widget.controller.errorMessage != null) {
          return Center(child: Text(widget.controller.errorMessage!));
        }

        if (widget.controller.orders.isEmpty) {
          return const Center(child: Text('No orders yet.'));
        }

        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: widget.controller.orders.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, index) {
            final order = widget.controller.orders[index];
            return Card(
              child: ListTile(
                title: Text('Order ${order.id}'),
                subtitle: Text(
                  '${order.status.name} • ${order.createdAt.toLocal()}',
                ),
                trailing: Text(
                  '${order.total.toStringAsFixed(3)} ${order.currency}',
                ),
              ),
            );
          },
        );
      },
    );
  }
}

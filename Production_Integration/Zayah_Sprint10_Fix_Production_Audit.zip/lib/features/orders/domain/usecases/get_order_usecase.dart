import '../entities/order.dart';
import '../repositories/order_repository.dart';

class GetOrderUseCase {
  const GetOrderUseCase(this._repository);

  final OrderRepository _repository;

  Future<ZayahOrder?> call(String orderId) {
    if (orderId.trim().isEmpty) {
      throw ArgumentError.value(orderId, 'orderId');
    }
    return _repository.getOrder(orderId);
  }
}

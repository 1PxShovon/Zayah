import '../entities/order.dart';
import '../repositories/order_repository.dart';

class WatchCustomerOrdersUseCase {
  const WatchCustomerOrdersUseCase(this._repository);

  final OrderRepository _repository;

  Stream<List<ZayahOrder>> call(String customerId) {
    if (customerId.trim().isEmpty) {
      throw ArgumentError.value(customerId, 'customerId');
    }
    return _repository.watchCustomerOrders(customerId);
  }
}

import '../entities/order.dart';

abstract interface class OrderRepository {
  Stream<List<ZayahOrder>> watchCustomerOrders(String customerId);

  Future<ZayahOrder?> getOrder(String orderId);
}

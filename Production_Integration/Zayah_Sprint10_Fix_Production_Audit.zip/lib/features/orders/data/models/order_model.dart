import 'package:cloud_firestore/cloud_firestore.dart';

import '../../domain/entities/order.dart';

class OrderModel extends ZayahOrder {
  const OrderModel({
    required super.id,
    required super.customerId,
    required super.total,
    required super.currency,
    required super.status,
    required super.createdAt,
  });

  factory OrderModel.fromFirestore(
    DocumentSnapshot<Map<String, dynamic>> snapshot,
  ) {
    final data = snapshot.data() ?? <String, dynamic>{};
    return OrderModel(
      id: snapshot.id,
      customerId: data['customerId'] as String? ?? '',
      total: (data['total'] as num?)?.toDouble() ?? 0,
      currency: data['currency'] as String? ?? 'KWD',
      status: _statusFromString(data['status'] as String?),
      createdAt: _dateFromTimestamp(data['createdAt']) ?? DateTime.fromMillisecondsSinceEpoch(0),
    );
  }

  static ZayahOrderStatus _statusFromString(String? value) {
    switch (value) {
      case 'confirmed':
        return ZayahOrderStatus.confirmed;
      case 'assigned':
        return ZayahOrderStatus.assigned;
      case 'accepted':
        return ZayahOrderStatus.accepted;
      case 'in_progress':
        return ZayahOrderStatus.inProgress;
      case 'completed':
        return ZayahOrderStatus.completed;
      case 'cancelled':
        return ZayahOrderStatus.cancelled;
      case 'pending_payment':
      default:
        return ZayahOrderStatus.pendingPayment;
    }
  }

  static DateTime? _dateFromTimestamp(dynamic value) {
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    return null;
  }
}

import '../../domain/entities/order.dart';
import '../../domain/repositories/order_repository.dart';
import '../datasources/order_firestore_datasource.dart';

class FirestoreOrderRepository implements OrderRepository {
  const FirestoreOrderRepository(this._dataSource);

  final OrderFirestoreDataSource _dataSource;

  @override
  Stream<List<ZayahOrder>> watchCustomerOrders(String customerId) {
    return _dataSource.watchCustomerOrders(customerId);
  }

  @override
  Future<ZayahOrder?> getOrder(String orderId) {
    return _dataSource.getOrder(orderId);
  }
}

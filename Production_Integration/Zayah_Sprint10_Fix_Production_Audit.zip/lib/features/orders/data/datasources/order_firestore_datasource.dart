import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/order_model.dart';

class OrderFirestoreDataSource {
  OrderFirestoreDataSource(this._firestore);

  final FirebaseFirestore _firestore;

  Stream<List<OrderModel>> watchCustomerOrders(String customerId) {
    return _firestore
        .collection('orders')
        .where('customerId', isEqualTo: customerId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map(OrderModel.fromFirestore)
              .toList(growable: false),
        );
  }

  Future<OrderModel?> getOrder(String orderId) async {
    final snapshot =
        await _firestore.collection('orders').doc(orderId).get();

    if (!snapshot.exists) return null;
    return OrderModel.fromFirestore(snapshot);
  }
}

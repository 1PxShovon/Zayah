import 'package:cloud_firestore/cloud_firestore.dart';

import '../../domain/entities/checkout_address.dart';
import '../../domain/entities/checkout_summary.dart';

class CheckoutFirestoreDataSource {
  CheckoutFirestoreDataSource(this._firestore);

  final FirebaseFirestore _firestore;

  Future<String> createPendingOrder({
    required CheckoutSummary summary,
    required CheckoutAddress address,
    String? customerId,
  }) async {
    final orderRef = _firestore.collection('orders').doc();

    await orderRef.set({
      'id': orderRef.id,
      'customerId': customerId,
      'status': 'pending_payment',
      'paymentStatus': 'pending',
      'currency': summary.currency,
      'subtotal': summary.subtotal,
      'serviceFee': summary.serviceFee,
      'total': summary.total,
      'items': summary.items
          .map(
            (item) => {
              'id': item.id,
              'name': item.name,
              'quantity': item.quantity,
              'unitPrice': item.unitPrice,
              'total': item.total,
            },
          )
          .toList(),
      'address': {
        'area': address.area,
        'block': address.block,
        'street': address.street,
        'building': address.building,
        'floor': address.floor,
        'notes': address.notes,
      },
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    return orderRef.id;
  }
}

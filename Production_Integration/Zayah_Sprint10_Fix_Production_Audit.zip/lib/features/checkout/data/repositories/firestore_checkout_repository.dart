import '../../domain/entities/checkout_address.dart';
import '../../domain/entities/checkout_summary.dart';
import '../../domain/repositories/checkout_repository.dart';
import '../datasources/checkout_firestore_datasource.dart';

class FirestoreCheckoutRepository implements CheckoutRepository {
  FirestoreCheckoutRepository({
    required CheckoutFirestoreDataSource dataSource,
    required String? Function() currentUserId,
  })  : _dataSource = dataSource,
        _currentUserId = currentUserId;

  final CheckoutFirestoreDataSource _dataSource;
  final String? Function() _currentUserId;

  @override
  Future<String> createPendingOrder({
    required CheckoutSummary summary,
    required CheckoutAddress address,
  }) {
    return _dataSource.createPendingOrder(
      summary: summary,
      address: address,
      customerId: _currentUserId(),
    );
  }
}

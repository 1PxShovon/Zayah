import 'dart:typed_data';

import '../../../../core/services/firebase_storage_service.dart';
import '../../../../core/storage/storage_path_builder.dart';
import '../../domain/entities/uploaded_media.dart';
import '../../domain/repositories/media_repository.dart';

class FirebaseMediaRepository implements MediaRepository {
  FirebaseMediaRepository({
    required FirebaseStorageService storage,
    required StoragePathBuilder paths,
  })  : _storage = storage,
        _paths = paths;

  final FirebaseStorageService _storage;
  final StoragePathBuilder _paths;

  @override
  Future<UploadedMedia> uploadProfileImage({
    required Uint8List bytes,
    required String contentType,
  }) async {
    final path = _paths.profileImage();
    final url = await _storage.uploadImage(
      path: path,
      bytes: bytes,
      contentType: contentType,
    );
    return UploadedMedia(
      path: path,
      downloadUrl: url,
      contentType: contentType,
      sizeBytes: bytes.length,
    );
  }

  @override
  Future<UploadedMedia> uploadProviderPortfolioImage({
    required String providerId,
    required String assetId,
    required Uint8List bytes,
    required String contentType,
  }) async {
    final path = _paths.providerPortfolioImage(providerId, assetId);
    final url = await _storage.uploadImage(
      path: path,
      bytes: bytes,
      contentType: contentType,
    );
    return UploadedMedia(
      path: path,
      downloadUrl: url,
      contentType: contentType,
      sizeBytes: bytes.length,
    );
  }

  @override
  Future<UploadedMedia> uploadServiceImage({
    required String providerId,
    required String serviceId,
    required String assetId,
    required Uint8List bytes,
    required String contentType,
  }) async {
    final path = _paths.serviceImage(providerId, serviceId, assetId);
    final url = await _storage.uploadImage(
      path: path,
      bytes: bytes,
      contentType: contentType,
    );
    return UploadedMedia(
      path: path,
      downloadUrl: url,
      contentType: contentType,
      sizeBytes: bytes.length,
    );
  }

  @override
  Future<UploadedMedia> uploadChatAttachment({
    required String conversationId,
    required String attachmentId,
    required Uint8List bytes,
    required String contentType,
  }) async {
    final path = _paths.chatAttachment(conversationId, attachmentId);
    final url = await _storage.uploadBytes(
      path: path,
      bytes: bytes,
      contentType: contentType,
      maxBytes: FirebaseStorageService.maxDocumentBytes,
    );
    return UploadedMedia(
      path: path,
      downloadUrl: url,
      contentType: contentType,
      sizeBytes: bytes.length,
    );
  }

  @override
  Future<void> delete(String path) => _storage.delete(path);
}

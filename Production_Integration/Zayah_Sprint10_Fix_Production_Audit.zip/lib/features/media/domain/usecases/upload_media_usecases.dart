import 'dart:typed_data';

import '../entities/uploaded_media.dart';
import '../repositories/media_repository.dart';

class UploadProfileImageUseCase {
  const UploadProfileImageUseCase(this._repository);
  final MediaRepository _repository;

  Future<UploadedMedia> call({
    required Uint8List bytes,
    required String contentType,
  }) {
    return _repository.uploadProfileImage(
      bytes: bytes,
      contentType: contentType,
    );
  }
}

class UploadProviderPortfolioImageUseCase {
  const UploadProviderPortfolioImageUseCase(this._repository);
  final MediaRepository _repository;

  Future<UploadedMedia> call({
    required String providerId,
    required String assetId,
    required Uint8List bytes,
    required String contentType,
  }) {
    return _repository.uploadProviderPortfolioImage(
      providerId: providerId,
      assetId: assetId,
      bytes: bytes,
      contentType: contentType,
    );
  }
}

class UploadServiceImageUseCase {
  const UploadServiceImageUseCase(this._repository);
  final MediaRepository _repository;

  Future<UploadedMedia> call({
    required String providerId,
    required String serviceId,
    required String assetId,
    required Uint8List bytes,
    required String contentType,
  }) {
    return _repository.uploadServiceImage(
      providerId: providerId,
      serviceId: serviceId,
      assetId: assetId,
      bytes: bytes,
      contentType: contentType,
    );
  }
}

class UploadChatAttachmentUseCase {
  const UploadChatAttachmentUseCase(this._repository);
  final MediaRepository _repository;

  Future<UploadedMedia> call({
    required String conversationId,
    required String attachmentId,
    required Uint8List bytes,
    required String contentType,
  }) {
    return _repository.uploadChatAttachment(
      conversationId: conversationId,
      attachmentId: attachmentId,
      bytes: bytes,
      contentType: contentType,
    );
  }
}

import 'dart:typed_data';

import '../entities/uploaded_media.dart';

abstract class MediaRepository {
  Future<UploadedMedia> uploadProfileImage({
    required Uint8List bytes,
    required String contentType,
  });

  Future<UploadedMedia> uploadProviderPortfolioImage({
    required String providerId,
    required String assetId,
    required Uint8List bytes,
    required String contentType,
  });

  Future<UploadedMedia> uploadServiceImage({
    required String providerId,
    required String serviceId,
    required String assetId,
    required Uint8List bytes,
    required String contentType,
  });

  Future<UploadedMedia> uploadChatAttachment({
    required String conversationId,
    required String attachmentId,
    required Uint8List bytes,
    required String contentType,
  });

  Future<void> delete(String path);
}

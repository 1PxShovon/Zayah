import 'package:equatable/equatable.dart';

class UploadedMedia extends Equatable {
  const UploadedMedia({
    required this.path,
    required this.downloadUrl,
    required this.contentType,
    required this.sizeBytes,
  });

  final String path;
  final String downloadUrl;
  final String contentType;
  final int sizeBytes;

  @override
  List<Object?> get props => [path, downloadUrl, contentType, sizeBytes];
}

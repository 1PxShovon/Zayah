import 'package:cloud_firestore/cloud_firestore.dart';

import '../domain/entities/technician_location.dart';
import 'technician_location_firestore_datasource.dart';

class TechnicianLocationRepository {
  TechnicianLocationRepository(this._dataSource);

  final TechnicianLocationFirestoreDataSource _dataSource;

  Stream<TechnicianLocation?> watch(String technicianId) {
    return _dataSource.watchLocation(technicianId).map((data) {
      if (data == null) return null;

      final lat = (data['latitude'] as num?)?.toDouble();
      final lng = (data['longitude'] as num?)?.toDouble();
      if (lat == null || lng == null) return null;

      final timestamp = data['updatedAt'];
      final updatedAt = timestamp is Timestamp
          ? timestamp.toDate()
          : DateTime.fromMillisecondsSinceEpoch(0);

      return TechnicianLocation(
        technicianId: technicianId,
        latitude: lat,
        longitude: lng,
        updatedAt: updatedAt,
      );
    });
  }

  Future<void> update({
    required String technicianId,
    required double latitude,
    required double longitude,
  }) {
    return _dataSource.setLocation(
      technicianId: technicianId,
      latitude: latitude,
      longitude: longitude,
    );
  }
}

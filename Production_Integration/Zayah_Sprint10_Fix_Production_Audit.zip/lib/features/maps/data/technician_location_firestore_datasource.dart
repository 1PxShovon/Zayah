import 'package:cloud_firestore/cloud_firestore.dart';

class TechnicianLocationFirestoreDataSource {
  TechnicianLocationFirestoreDataSource(this._firestore);

  final FirebaseFirestore _firestore;

  Stream<Map<String, dynamic>?> watchLocation(String technicianId) {
    return _firestore
        .collection('technician_locations')
        .doc(technicianId)
        .snapshots()
        .map((snapshot) => snapshot.data());
  }

  Future<void> setLocation({
    required String technicianId,
    required double latitude,
    required double longitude,
  }) {
    return _firestore
        .collection('technician_locations')
        .doc(technicianId)
        .set({
      'technicianId': technicianId,
      'latitude': latitude,
      'longitude': longitude,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }
}

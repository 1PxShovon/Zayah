import '../entities/technician_location.dart';
import '../../data/technician_location_repository.dart';

class WatchTechnicianLocation {
  const WatchTechnicianLocation(this._repository);

  final TechnicianLocationRepository _repository;

  Stream<TechnicianLocation?> call(String technicianId) {
    return _repository.watch(technicianId);
  }
}

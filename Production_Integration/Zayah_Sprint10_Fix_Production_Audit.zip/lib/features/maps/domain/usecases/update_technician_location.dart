import '../../data/technician_location_repository.dart';

class UpdateTechnicianLocation {
  const UpdateTechnicianLocation(this._repository);

  final TechnicianLocationRepository _repository;

  Future<void> call({
    required String technicianId,
    required double latitude,
    required double longitude,
  }) {
    return _repository.update(
      technicianId: technicianId,
      latitude: latitude,
      longitude: longitude,
    );
  }
}

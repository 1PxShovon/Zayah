import 'package:equatable/equatable.dart';

class TechnicianLocation extends Equatable {
  const TechnicianLocation({
    required this.technicianId,
    required this.latitude,
    required this.longitude,
    required this.updatedAt,
  });

  final String technicianId;
  final double latitude;
  final double longitude;
  final DateTime updatedAt;

  @override
  List<Object?> get props => [
        technicianId,
        latitude,
        longitude,
        updatedAt,
      ];
}

import 'package:flutter/foundation.dart';

import '../../data/services/auth_service.dart';

class AuthController extends ChangeNotifier {
  AuthController({required AuthService service}) : _service = service;

  final AuthService _service;

  bool isLoading = false;
  String? errorMessage;

  Future<bool> signIn({required String email, required String password}) async {
    if (isLoading) return false;
    isLoading = true;
    errorMessage = null;
    notifyListeners();

    try {
      await _service.signIn(email: email, password: password);
      return true;
    } catch (error) {
      final text = error.toString();
      if (text.contains('invalid-credential') || text.contains('wrong-password')) {
        errorMessage = 'Email or password is incorrect.';
      } else if (text.contains('user-not-found')) {
        errorMessage = 'No account was found for this email.';
      } else {
        errorMessage = 'Unable to sign in. Please try again.';
      }
      return false;
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }
}

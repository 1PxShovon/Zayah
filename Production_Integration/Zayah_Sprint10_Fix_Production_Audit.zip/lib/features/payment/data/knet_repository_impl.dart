import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../domain/entities/payment_transaction.dart';
import '../domain/repositories/knet_repository.dart';
import 'knet_backend_client.dart';

class KnetRepositoryImpl implements KnetRepository {
  KnetRepositoryImpl({
    required KnetBackendClient backend,
    required FirebaseFirestore firestore,
    required FirebaseAuth auth,
  }) : _backend=backend, _firestore=firestore, _auth=auth;

  final KnetBackendClient _backend;
  final FirebaseFirestore _firestore;
  final FirebaseAuth _auth;

  @override
  Future<PaymentTransaction> createPayment({
    required String orderId,
    required double amount,
    required String currency,
  }) async {
    final uid=_auth.currentUser?.uid;
    if (uid==null) throw StateError('Authentication required');

    final data=await _backend.createPayment(
      orderId: orderId, amount: amount, currency: currency);

    final id=data['transactionId'] as String?;
    if (id==null || id.isEmpty) throw const FormatException('Missing transactionId');

    final tx=PaymentTransaction(
      transactionId:id, orderId:orderId, userId:uid, amount:amount,
      currency:currency, status:_map(data['status']),
      createdAt:DateTime.now(),
      gatewayReference:data['gatewayReference'] as String?,
      paymentUrl:data['paymentUrl'] as String?,
    );

    await _firestore.collection('payment_transactions').doc(id).set({
      'transactionId':id, 'orderId':orderId, 'userId':uid,
      'amount':amount, 'currency':currency, 'status':tx.status.name,
      'gatewayReference':tx.gatewayReference, 'paymentUrl':tx.paymentUrl,
      'createdAt':FieldValue.serverTimestamp(),
    });
    return tx;
  }

  @override
  Future<PaymentTransaction> refreshPaymentStatus(String transactionId) async {
    final uid=_auth.currentUser?.uid;
    if (uid==null) throw StateError('Authentication required');

    final data=await _backend.status(transactionId);
    final snap=await _firestore.collection('payment_transactions').doc(transactionId).get();
    final old=snap.data() ?? {};

    return PaymentTransaction(
      transactionId:transactionId,
      orderId:old['orderId'] as String? ?? '',
      userId:uid,
      amount:(old['amount'] as num?)?.toDouble() ?? 0,
      currency:old['currency'] as String? ?? 'KWD',
      status:_map(data['status']),
      createdAt:old['createdAt'] is Timestamp
          ? (old['createdAt'] as Timestamp).toDate()
          : DateTime.fromMillisecondsSinceEpoch(0),
      gatewayReference:data['gatewayReference'] as String? ?? old['gatewayReference'] as String?,
      paymentUrl:old['paymentUrl'] as String?,
    );
  }

  PaymentStatus _map(Object? v) {
    switch ('$v'.toLowerCase()) {
      case 'paid': case 'success': case 'successful': return PaymentStatus.paid;
      case 'failed': return PaymentStatus.failed;
      case 'cancelled': case 'canceled': return PaymentStatus.cancelled;
      case 'refunded': return PaymentStatus.refunded;
      default: return PaymentStatus.pending;
    }
  }
}

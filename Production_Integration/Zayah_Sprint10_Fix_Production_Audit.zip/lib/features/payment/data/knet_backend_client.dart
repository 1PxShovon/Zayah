import 'dart:convert';
import 'package:http/http.dart' as http;

class KnetBackendClient {
  KnetBackendClient({required http.Client client, required String baseUrl})
      : _client = client,
        _baseUrl = baseUrl.replaceFirst(RegExp(r'/$'), '');

  final http.Client _client;
  final String _baseUrl;

  Future<Map<String, dynamic>> createPayment({
    required String orderId,
    required double amount,
    required String currency,
  }) async {
    final r = await _client.post(
      Uri.parse('$_baseUrl/payments/knet/create'),
      headers: const {'content-type': 'application/json'},
      body: jsonEncode({'orderId': orderId, 'amount': amount, 'currency': currency}),
    );
    return _decode(r);
  }

  Future<Map<String, dynamic>> status(String transactionId) async {
    final r = await _client.get(
      Uri.parse('$_baseUrl/payments/knet/$transactionId'),
      headers: const {'content-type': 'application/json'},
    );
    return _decode(r);
  }

  Map<String, dynamic> _decode(http.Response r) {
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception('KNET backend error: ${r.statusCode}');
    }
    final v = jsonDecode(r.body);
    if (v is! Map<String, dynamic>) throw const FormatException('Invalid response');
    return v;
  }
}

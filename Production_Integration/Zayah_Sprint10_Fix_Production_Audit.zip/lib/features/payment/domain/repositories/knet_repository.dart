import '../entities/payment_transaction.dart';

abstract class KnetRepository {
  Future<PaymentTransaction> createPayment({
    required String orderId,
    required double amount,
    required String currency,
  });

  Future<PaymentTransaction> refreshPaymentStatus(String transactionId);
}

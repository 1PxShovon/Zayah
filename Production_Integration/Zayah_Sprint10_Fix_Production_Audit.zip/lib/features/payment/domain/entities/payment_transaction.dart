import 'package:equatable/equatable.dart';

enum PaymentStatus { pending, paid, failed, cancelled, refunded }

class PaymentTransaction extends Equatable {
  const PaymentTransaction({
    required this.transactionId,
    required this.orderId,
    required this.userId,
    required this.amount,
    required this.currency,
    required this.status,
    required this.createdAt,
    this.gatewayReference,
    this.paymentUrl,
  });

  final String transactionId;
  final String orderId;
  final String userId;
  final double amount;
  final String currency;
  final PaymentStatus status;
  final DateTime createdAt;
  final String? gatewayReference;
  final String? paymentUrl;

  @override
  List<Object?> get props => [
    transactionId, orderId, userId, amount, currency, status,
    createdAt, gatewayReference, paymentUrl
  ];
}

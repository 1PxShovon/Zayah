import '../entities/payment_transaction.dart';
import '../repositories/knet_repository.dart';

class RefreshKnetPayment {
  const RefreshKnetPayment(this.repository);
  final KnetRepository repository;
  Future<PaymentTransaction> call(String id) => repository.refreshPaymentStatus(id);
}

import '../entities/payment_transaction.dart';
import '../repositories/knet_repository.dart';

class CreateKnetPayment {
  const CreateKnetPayment(this.repository);
  final KnetRepository repository;
  Future<PaymentTransaction> call({
    required String orderId, required double amount, String currency='KWD'
  }) => repository.createPayment(orderId:orderId, amount:amount, currency:currency);
}

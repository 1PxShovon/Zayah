enum BookingPaymentState {
  pendingPayment,
  paymentPending,
  paid,
  paymentFailed,
  cancelled,
  confirmed,
}

import 'package:cloud_firestore/cloud_firestore.dart';

class ConfirmPaidBooking {
  ConfirmPaidBooking(this._firestore);

  final FirebaseFirestore _firestore;

  Future<void> call({
    required String orderId,
    required String transactionId,
  }) async {
    // The client may only request a refresh. It must never promote an order
    // to confirmed based on local state. The callable/backend remains the
    // authority for this transition.
    final payment = await _firestore
        .collection('payment_transactions')
        .doc(transactionId)
        .get();

    if (!payment.exists || payment.data()?['status'] != 'paid') {
      throw StateError('Payment is not verified.');
    }

    throw StateError(
      'Order confirmation is server-authoritative. '
      'Use the payment verification backend endpoint.',
    );
  }
}

# Zayah

Zayah is a production-first Kuwait service marketplace for customers, Zayah's own service team, and external service providers.

## Current recovery state

This repository was reconstructed from the uploaded Zayah backup on 08 August 2026.

### Active foundation

- Flutter application root
- Responsive Web foundation
- Clean feature-oriented `lib/` structure
- GoRouter navigation
- GetIt dependency bootstrap
- Authentication UI foundation
- Checkout foundation
- Order entity foundation
- Existing legacy implementation artifacts preserved under `legacy_source/`

### Locked production integration order

1. Project validation and compile cleanup
2. GoRouter + GetIt completion
3. Firebase Auth / Firestore / Storage
4. Firebase Cloud Messaging
5. Google Maps + technician live tracking
6. Real KNET backend + callback verification
7. End-to-end booking → payment → order → completion
8. Testing, security, performance, and release

No new large business feature should be started until the locked integration sprint is complete.

## External configuration required

Real Firebase, Maps, KNET, Android, and iOS production setup requires credentials/configuration that were not included in the uploaded backup. Never commit secrets to Git.

## Production Firebase setup

Web builds must receive Firebase values through `--dart-define` (or an equivalent CI secret mechanism). Never commit production credentials to source control.

Example shape:

```bash
flutter build web \
  --dart-define=APP_ENV=production \
  --dart-define=FIREBASE_API_KEY=*** \
  --dart-define=FIREBASE_APP_ID=*** \
  --dart-define=FIREBASE_MESSAGING_SENDER_ID=*** \
  --dart-define=FIREBASE_PROJECT_ID=*** \
  --dart-define=FIREBASE_AUTH_DOMAIN=*** \
  --dart-define=FIREBASE_STORAGE_BUCKET=***
```

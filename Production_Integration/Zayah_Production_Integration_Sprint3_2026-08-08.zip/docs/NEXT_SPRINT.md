# Zayah Production Integration Queue

## Sprint 1 — completed in recovery pass
- Corrected the application `pubspec.yaml`.
- Added guarded Firebase bootstrap.
- Added GetIt registrations for Firebase Auth, Firestore and checkout.
- Replaced checkout's in-memory repository with the Firestore repository.
- Added initial Firestore and Storage security rules.
- Preserved recovered legacy source under `legacy_source/`.

## Sprint 2 — Firestore + Storage
- Added a shared `FirestoreService` facade for feature repositories.
- Added `FirebaseStorageService` with image/document type and size validation.
- Registered Firestore and Storage services in GetIt.
- Kept feature repositories responsible for domain/model mapping.

## Locked next work
1. Migrate existing feature repositories to the shared Firestore service.
2. Add authenticated user/profile persistence.
3. Add Provider portfolio/document upload use cases.
4. Add chat attachment upload use case.
5. Then implement FCM token registration and notification handling.
6. Then Google Maps configuration/live location.
7. Then server-side KNET payment contract and callback verification.
8. Automated tests and platform builds.

No new major business feature should start before this integration queue is complete.

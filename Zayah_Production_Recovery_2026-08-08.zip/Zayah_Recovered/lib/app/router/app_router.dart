import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/presentation/pages/sign_in_page.dart';
import '../../features/checkout/data/repositories/in_memory_checkout_repository.dart';
import '../../features/checkout/domain/services/checkout_service.dart';
import '../../features/checkout/presentation/controllers/checkout_controller.dart';
import '../../features/checkout/presentation/pages/checkout_page.dart';
import '../../features/home/presentation/pages/home_page.dart';
import 'app_routes.dart';

final GlobalKey<NavigatorState> rootNavigatorKey = GlobalKey<NavigatorState>();

final GoRouter appRouter = GoRouter(
  navigatorKey: rootNavigatorKey,
  initialLocation: AppRoutes.home,
  routes: <RouteBase>[
    GoRoute(
      path: AppRoutes.home,
      builder: (context, state) => const HomePage(),
    ),
    GoRoute(
      path: AppRoutes.signIn,
      builder: (context, state) => const SignInPage(),
    ),
    GoRoute(
      path: AppRoutes.checkout,
      builder: (context, state) {
        final repository = InMemoryCheckoutRepository();
        final service = CheckoutService(repository: repository);
        final controller = CheckoutController(service: service);
        return CheckoutPage(controller: controller);
      },
    ),
  ],
  errorBuilder: (context, state) => Scaffold(
    appBar: AppBar(title: const Text('Zayah')),
    body: Center(
      child: Text('Page not found: ${state.uri.path}'),
    ),
  ),
);

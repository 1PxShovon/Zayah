import 'package:get_it/get_it.dart';

final GetIt sl = GetIt.instance;

Future<void> configureDependencies() async {
  if (!sl.isRegistered<DependencyContainer>()) {
    sl.registerSingleton<DependencyContainer>(DependencyContainer());
  }
}

class DependencyContainer {
  const DependencyContainer();
}

rules_version = '2';

service cloud.firestore {

match /databases/{database}/documents {

match /users/{userId} {

allow read, write:

if request.auth.uid == userId;

}

match /orders/{orderId} {

allow read:

if request.auth != null;

}

}

}